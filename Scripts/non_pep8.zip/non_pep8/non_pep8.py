#!/usr/bin/env python
# -*- coding: utf-8 -*-

def foo():
    msgs=['Hello','World!!']
    print ','.join(msgs)

if __name__ == '__main__':
    foo()